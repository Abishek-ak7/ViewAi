import React from 'react'
import Home from './Home'
import About from './About'
import ConnectWithUs from './ConnectWithUs'

export default function Main() {
  return (
    <div>
        <Home />
        <About/>
        <ConnectWithUs/>
       
    </div>
  )
}
