import React from 'react'
import '../assests/Home.css';
import bot from '../assests/images/chat-bot.png'
import cube from '../assests/images/cube.png'
import key from '../assests/images/license-key 4.png'
import wall from '../assests/images/firewall.png'
import print from '../assests/images/printer.png'
import human from '../assests/images/cyborg 4.png'
import slide from '../assests/images/Icon Container.png'
import Card from './Card'

const  Unique = () => {
  const cardData = [
    {
      image: bot,
      heading: 'Advanced AI Personalization',
    },
    {
      image: cube,
      heading: '3D Model Customization',
    },
    {
      image: key,
      heading: 'Custom AI Integration',
    },
    {
      image: wall,
      heading: 'User-Friendly Panel',
    },
    {
      image: wall,
      heading: 'Efficient CI/CD Pipeline',
    },
    {
      image: print,
      heading: 'Responsive Design',
    },
    {
      image: human,
      heading: 'Data Driven Insights',
    },
    {
      image: slide,
      heading: 'Get started with ViewAI',
    },
  ];

  return (
    <div className="flex flex-wrap md:justify-between md:mx-auto">
      {cardData.map((card, index) => (
        <div key={index} className="w-full pb-5 md:w-1/2 lg:w-1/3 xl:w-1/4 md:p-5">
          <Card image={card.image} heading={card.heading} />
        </div>
      ))}
    </div>
  );
}
export default Unique;