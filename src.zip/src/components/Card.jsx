import React from 'react';

const Card = ({ image, heading }) => {
  return (
    <div className="card flex flex-col justify-center items-center w-full p-3 lg:p-0 xl:p-3 shadow-md rounded-lg overflow-hidden">
      <img src={image} alt={heading} className="w-1/2 h-1/2 mx-auto" />
      <h2 className="text-center md:text-lg xl:text-xl sm:text-base xs:text-xs font-semibold p-8 text-white mt-5 w-full md:w-full sm:text-wrap">
        {heading}
      </h2>
    </div>
  );
};

export default Card;
