import React from 'react';
import '../assests/Home.css';
import logo from '../assests/images/Vector (1).png';
import text from '../assests/images/VIEW AI.png';
import profile from '../assests/images/Profile.png';
import star from '../assests/images/Group_27-removebg-preview.png';
import star1 from '../assests/images/Star 1.png';
import arrow from '../assests/images/Group 102.png';
import mlogo from '../assests/images/ep_menu.png'
import bg from '../assests/images/iPad Mini.png';
import b from '../assests/images/Rectangle 158.png';
import Unique from './Unique';
import  { useState, useEffect } from "react";
import { FontAwesomeIcon } from '@fortawesome/react-fontawesome';
import {faTimes } from '@fortawesome/free-solid-svg-icons';
import {Link} from 'react-scroll'


const Home = () =>{
  const [isVisible, setIsVisible] = useState(false);
  const [menuOpen, setMenuOpen] = useState(false);

  const handleClose = () => {
    setIsVisible(false);
    document.body.style.overflow = 'auto';
  };

  const toggleMenu = () => {
    setMenuOpen(!menuOpen);
    document.body.style.overflow = menuOpen ? 'auto' : 'hidden';
  };

  useEffect(() => {
    const handleKeyPress = (e) => {
      if (e.keyCode === 27) {
        handleClose();
        if (menuOpen) toggleMenu();
      }
    };

    if (isVisible || menuOpen) {
      window.addEventListener('keydown', handleKeyPress);
    }

    return () => {
      window.removeEventListener('keydown', handleKeyPress);
    };
  }, [isVisible, menuOpen]);

  return (
    <div className="Home bg-ipad-mini p-4 min-h-screen overflow-hidden" id="Home">
      <div className="relative flex justify-between items-center">
        <div className="flex items-center space-x-2">
          <div className="relative">
            <img src={logo} className="flex ml-5 mt-3 w-16 h-10" alt="Logo" />
            <img src={star1} className="absolute top-2 left-14 w-4 h-4" alt="Star" />
            <img src={star} className="absolute top-1 left-16 w-4 h-4" alt="Star 1" />
          </div>
          <img src={text} className="h-7 mt-3" alt="View AI" />
        </div>
        <div className='hidden sm:hidden md:block lg:block'>
          <div className="flex justify-evenly pr-2 py-0.5 mr-10 mt-3">
            <img src={profile} className="w-8 h-8 mr-2 rounded-full ml-0.5 border-2 border-white" alt="Profile" />
            <p className="text-white mr-1 text-xl cursor-pointer mb-0.5 font-bold">Connect</p>
          </div>
        </div>
        <div className='bg-white/45 p-1 border-2 rounded-full block sm:block md:hidden lg:hidden'>
          <div className='bg-black/60 border-2 border-white rounded-full'>
            <img src={mlogo} onClick={toggleMenu} className='w-8 h-8 p-1' alt="Menu" />
          </div>
        </div>
        {menuOpen && (
          <div className="fixed inset-0 bg-white/10 h-3/4 ml-auto border-white border-2 backdrop-blur flex flex-col items-center justify-center w-1/2">
            <button onClick={toggleMenu} className="absolute top-4 right-4 text-black">
              <FontAwesomeIcon icon={faTimes} style={{ width: '25px', height: '35px' }} />
            </button>
            <ul className="flex flex-col gap-6 text-start -mt-14">
              <li><Link onClick={toggleMenu} to="Home" spy={true} smooth={true} offset={-350} duration={500} className=" text-white font-bold text-lg  ">Home</Link></li>
              <li><Link onClick={toggleMenu} to="second" spy={true} smooth={true} offset={5} duration={500} className=" text-white font-bold text-lg  ">Make us Unique</Link></li>
              <li><Link onClick={toggleMenu} to="about" spy={true} smooth={true} offset={50} duration={500} className=" text-white font-bold text-lg  ">About</Link></li>
              <li><Link onClick={toggleMenu} to="contact" spy={true} smooth={true} offset={50} duration={500} className=" text-white font-bold text-lg  ">Connect with us</Link></li>
            </ul>
          </div>
        )}
      </div>
      <div className='flex justify-end h-full'>
        <div className='md:mt-9'>
          <div className='w-1/2 mt-14 md:mt-0 md:w-1/3 xl:w-1/4 xl:left-80 md:left-10 absolute h-4/5 sm:transparent md:bg-gray-800 rounded-xl md:backdrop-blur-sm md:bg-opacity-20 lg:bg-opacity-20 xl:bg-opacity-20 md:border-2 lg:border-2 xl:border-2 md:border-gray-500 lg:border-gray-500 xl:border-gray-500 pt-10'>
            <div className='flex bg-transparent md:pt-16 w-full px-3'>
              <img src={text} className="bg-transparent w-full h-full md:w-full md:h-2/3" alt="View AI" />
            </div>
            <div className='flex md:mt-10 mt-3 bg-transparent'>
              <img src={b} className='md:w-3 md:h-10 w-3 h-10 md:mt-5' alt="" />
              <p className='text-white md:text-3xl w-full sm:text-lg bg-transparent pl-3'>AI and E-Commerce Innovation</p>
            </div>
            <p className='text-white md:mt-10 mt-3 w-11/12 whitespace-normal bg-transparent px-3 ml-2'>We revolutionize formal wear shopping with our custom e-commerce platform.</p>
            <div className='flex mt-10 items-center p-1 w-3/4 md:w-3/4 md:mt-4 justify-center md:bg-white/30 md:rounded-full rounded-lg lg:mt-10 xl:mt-28 md:border-2 border-[1px] md:border-white border-gray-600 md:ml-4 ml-1'>
              <p className='text-white text-xl font-semibold pb-1 bg-transparent'>Get Started</p>
              <img src={arrow} className='w-8 h-8 bg-transparent rounded-full p-1' alt="Arrow" />
            </div>
          </div>
        </div>
        <div>
          <img src={bg} className='md:h-screen h-fit mt-14 w-full md:-mt-8 ml-36' alt='ipad mini' />
        </div>
      </div>
      <div className='mt-44 md:mt-0' id="second">
        <div className='flex items-center justify-center'>
          <h1 className='text-4xl font-semibold text-white'>Making Us Unique</h1>
        </div>
        <p className='md:ml-20 text-center mt-10 text-lg text-white md:mb-10'>Our custom formal e-commerce SaaS platform stands out by integrating cutting-edge AI for personalized recommendations,<br />
          real-time virtual tailoring, and seamless multi-brand integration. Built with a robust backend using Python and cloud-native technologies, our platform ensures scalability, security, and an exceptional user experience.
        </p>
      </div>
      <div className="Unique">
        <div className='flex md:justify-center md:items-center mx-auto'>
          <Unique />
        </div>
      </div> 
    </div>
  );
}
export default Home;